


var aracBilgileri = {
    id : "bmw116d_123" , 
    yil : 2015 ,
    renk : "white" ,
    servisKayitlari : [
        {
            id : "bmw116d_1234_1" , 
            tarih :("30/01/2016") , 
            km : 13000 , 
            Tucret : 900 ,
            servisDetayi : [ {
                id : 1 , islem : "yağ değişimi" , ucret : 300 
            } ,
            {
                id : 2 , islem : "filtre değişimi" , ucret : 300 
            } , 
            {
                id : 3 , islem : "fren hidroliği" , ucret : 300 
            }  
            ]
        }, 

        {
            id : "bmw116d_1234_2" , 
            tarih : ("10/01/2017") , 
            km : 28000 , 
            Tucret : 1800 ,
            servisDetayi : [ {
                id : 1 , islem : "yağ değişimi" , ucret : 350 
            } ,
            {
                id : 2 , islem : "filtre değişimi" , ucret : 350 
            } , 
            {
                id : 3 , islem : "fren hidroliği" , ucret : 300 
            },
            {
                id : 4 , islem : "balata değişimi" , ucret : 800
            }
            ]   
        }
    ]
}

console.log(aracBilgileri);